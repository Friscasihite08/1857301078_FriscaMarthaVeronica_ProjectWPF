import React,{useState,useEffect} from 'react';
import axios from 'axios';
import Constants from 'expo-constants';
import { Text,FlatList, ActivityIndicator, StyleSheet, Image, View ,Dimensions,TouchableOpacity } from 'react-native';
 
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default function Layout2Cari({navigation}){
  const [fasilitas,setFasilitas]=useState([])
    const getFasilitas = async () => {
      try {
        const dataFasilitas = await axios.get(
          'https://murmuring-lowlands-06200.herokuapp.com/api/fasilitas'
        );
        setFasilitas(dataFasilitas.data);
        console.log(dataFasilitas.data);
      }catch (err) {
        console.error(err.message);
      }
    };
    useEffect(()=>{
      getFasilitas()
    },[]
    )
       return (
         <View>
    <View>
          <Image source={{uri:'https://pbs.twimg.com/profile_images/917215882928984064/Bs-OTILS.jpg'}} 
          style={{
            height:600,
            borderTopLeftRadius:20,
            borderTopRightRadius:20,
            borderBottomLeftRadius:20,
            borderBottomRightRadius:20,
            position:"absolute",
            zIndex:-999,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          }}
          />
      </View>
    <View style={styles.container}>
        <View
        style={{
          backgroundColor:'white',
          flex:1,
          marginTop:30,
          borderRadius:40
        }}
        >
        <View
         style={{
         flex:1,
         height:70,
         borderRadius:20,
         alignContent:'flex-end',
         flexDirection:'row-reverse',
         padding:40
       }}>
        <View>
        <TouchableOpacity onPress={()=> navigation.navigate('Home')}>
         <Ionicons name="close" size={20} color="black"
            style={{
              backgroundColor:"#fff5f5",
              padding:10,
              marginRight:-20,
              borderRadius:50
            }}
            />
            </TouchableOpacity>
        </View>
        <View
       style={{
       marginTop:50,
       left:50,
       width:300,
       height:50,
       padding:10,
       borderColor:'grey',
       borderWidth:2,
       borderRadius:25,
       flexDirection:'row',
       alignItems:"center",
       justifyContent:"center"
       }}>
      <Text
     style={{
       fontSize:12,
       fontWeight:"bold",
       marginLeft:20,
       color:'grey'}}>
       Cari Fasilitas</Text>
       <View
       style={{
         alignItems:'flex-end',
         width:200,
       }}>
       <Ionicons name="search" size={25} color="black"
      style={{
        alignItems:'flex-end',
        
      }}/>
       </View>
    
    </View>
        </View>
    <View
    style={{
         flex:3,
         marginLeft:15
       }}>
      <Text
        style={{
          fontSize:18,
          color:'grey',
          marginTop:25
        }}
       >Popular Facilities
       </Text> 
    </View>
    
 <FlatList
                   data={fasilitas}
                   renderItem={({ item }) => (
                     <>
                     
                     <View style={{
                       marginLeft:10,
                       marginTop:10,
                       marginBottom:10,
                       justifyContent:"space-between",
                       flexDirection:"row",
                       alignItems:'center',
                       padding:10,
                       width:300,
                       borderRadius:20,
                       backgroundColor:'pink'
                     }}>
                      <View
                      style={{
                        flexDirection:'row',
                      }}
                      >
                          <Image style={styles.gambar} source={{uri:'https://murmuring-lowlands-06200.herokuapp.com/gambar/'+item.foto}}/>
                          <View>
                         
                           <Text
                          style={{
                            paddingLeft:20,
                            fontWeight:"bold"
                          }}
                          >{item.nama}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >{item.jumlah}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >{item.id_kategori.nama}</Text>
                          </View>
                          
                          
                      </View>
                      <TouchableOpacity onPress={()=> navigation.navigate('Detail',item)}>
                        <Ionicons name="caret-forward-outline" size={25} color="black"
      style={{
        alignItems:'flex-end',
        marginRight:20
        
      }}/>
    </TouchableOpacity>
                     </View>
                     </>
                      )}
                   keyExtractor={({ id }, index) => id}
               />

      </View>
        </View>
        </View>
       );

 
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    padding: 0,
  },
  header:{
    flexDirection:'row',
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    alignItems:"center",
    justifyContent:"space-between",
  },
  fasilitas: {
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'white',
    height:70,
    justifyContent:'space-between',
    borderRadius:30,
    marginTop:20
  },
  gambar:{
    height:55,
    width:75,
    borderRadius:10,
    borderWidth:1,
    position:'flex'
  },
});