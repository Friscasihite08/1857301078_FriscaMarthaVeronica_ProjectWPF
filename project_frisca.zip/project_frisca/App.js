import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import Layout1Menu from './Layout1Menu';
import Layout2Cari from './Layout2Cari';
import Layout3Detail from './Layout3Detail';
import Layout4Peminjaman from './Layout4Peminjaman';
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
    <Stack.Navigator screenOptions={{
        headerShown: false
      }}>
      <Stack.Screen name="Home" component={Layout1Menu}/>
      <Stack.Screen name="Cari" component={Layout2Cari}/>
      <Stack.Screen name="Detail" component={Layout3Detail}/>
      <Stack.Screen name="Peminjaman" component={Layout4Peminjaman}/>
      </Stack.Navigator>
      </NavigationContainer>
  );
}

const styles = StyleSheet.create({
});
