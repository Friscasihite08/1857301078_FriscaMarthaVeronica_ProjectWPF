import React,{useState,useEffect} from 'react';
import axios from 'axios';
import { FlatList,Text, View, StyleSheet,Image,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';

export default function Layout3Detail({route,navigation}) {
  const dataList=route.params
  const [fasilitas,setFasilitas]=useState([])
    const getFasilitas = async () => {
      try {
        const dataFasilitas = await axios.get(
          'https://murmuring-lowlands-06200.herokuapp.com/api/fasilitas'
        );
        setFasilitas(dataFasilitas.data);
        console.log(dataFasilitas.data);
      }catch (err) {
        console.error(err.message);
      }
    };
    useEffect(()=>{
      getFasilitas()
    },[]
    )
  return (
    <View>
    <View>
          <Image source={{uri: 'https://murmuring-lowlands-06200.herokuapp.com/gambar/'+dataList.foto}}
          style={{
            height:440,
            borderTopLeftRadius:20,
            borderTopRightRadius:20,
            borderBottomLeftRadius:20,
            borderBottomRightRadius:20,
            position:"absolute",
            zIndex:-999,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          }}
          />
      </View>
    <View style={styles.container}>
        <View style={styles.header}>
        <TouchableOpacity onPress={()=> navigation.navigate('Cari')}>
            <Ionicons name="arrow-back-outline" size={20} color="black"
            style={{
              backgroundColor:"#fff5f5",
              padding:10,
              borderRadius:60,
            }}
            />
            </TouchableOpacity>
        <Ionicons name="heart-outline" size={20} color="black"
            style={{
              backgroundColor:"#fff5f5",
              padding:10,
              borderRadius:60,
            }}
            />
        </View>
    <View
         style={{
           marginTop:220,
           height:200,
              backgroundColor:"#fff0f0",
              padding:10,
              borderTopLeftRadius:40,
              borderTopRightRadius:40,
              borderBottomLeftRadius:50,
              borderBottomRightRadius:50,
              fontWeight:"bold",
              flexDirection:'row',
              alignItems:"center",
              
        }}
        >
       <View
       style={{
         flex:3,
         marginLeft:15
       }}
       >
        <Text
        style={{
          fontWeight:"bold",
          fontSize:20,
          color:'black',
          marginTop:-30
        }}
       >
        {dataList.id_kategori.nama}
       </Text>
        <Text
         style={{
          fontSize:15,
          width:275,
          color:'grey',
          marginTop:25,
        }}
        >{dataList.nama}</Text>
        <Text
        style={{
          fontSize:15,
          color:'black',
          marginTop:20,
        }}>Jumlah Kapasitas :</Text>
        <View
        style={{
          flexDirection:"row"
        }}>
        <Text
         style={{
          fontSize:15,
          width:80,
          color:'#e7997c',
          marginTop:25,
        }}
        >{dataList.jumlah}</Text>
        <Text style={{
          fontSize:15,
          width:275,
          color:'black',
          marginTop:25,
        }}>Orang</Text>
       </View>
      </View>
        </View> 

        <View
    style={{
         flex:3,
         marginLeft:15
       }}>
      <Text
        style={{
          fontSize:18,
          color:'grey',
          marginTop:25
        }}
       >{dataList.id_kategori.nama} Facilities
       </Text> 
    </View>

      <View
         style={{
           marginTop:30,
           height:100,
              backgroundColor:"#fff5f5",
              padding:10,
              borderTopLeftRadius:30,
              borderTopRightRadius:30,
              borderBottomLeftRadius:30,
              borderBottomRightRadius:30,
              fontWeight:"bold",
              flexDirection:'row',
              alignItems:"center",
              
        }}
        >
       <View
       style={{
         flex:3,
         marginLeft:10
       }}
       >
        <Text
        style={{
          fontWeight:"bold",
          fontSize:14,
          color:'black'
        }}
       ><Ionicons name="star" size={20} color=""
            style={{
              padding:5,
            }}
            />
        Keterangan
       </Text>
        <Text
         style={{
          fontSize:12,
          color:'grey',
          marginTop:5,
          padding:5
        }}
        >{dataList.informasi}</Text>
       </View>
      </View>
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    padding: 8,
  },
  header:{
    flexDirection:'row',
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    alignItems:"center",
    justifyContent:"space-between",
    
  }
});