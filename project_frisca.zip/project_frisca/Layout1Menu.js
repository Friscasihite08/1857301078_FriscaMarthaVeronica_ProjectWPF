import * as React from 'react';
import { Text, View, StyleSheet,Image,TouchableOpacity } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';

export default function Layout1Menu({navigation}) {
  return (
    <View>
    <View>
          <Image source={{uri:'https://pbs.twimg.com/profile_images/917215882928984064/Bs-OTILS.jpg'}} 
          style={{
            height:500,
            borderTopLeftRadius:20,
            borderTopRightRadius:20,
            borderBottomLeftRadius:20,
            borderBottomRightRadius:20,
            position:"absolute",
            zIndex:-999,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          }}
          />
      </View>
    <View style={styles.container}>
        <View style={styles.header}>
            <Ionicons name="filter-outline" size={20} color="black"
            style={{
              backgroundColor:"#fff5f5",
              padding:10,
              borderRadius:60,
            }}
            />
        <TouchableOpacity onPress={()=> navigation.navigate('Cari')}>
        <Text
        style={{
              backgroundColor:"#fff5f5",
              padding:10,
              borderRadius:70,
        }}
        >Cari Fasilitas
        </Text>
        </TouchableOpacity>
        </View>
        <View
         style={{
           marginTop:230,
           height:100,
              backgroundColor:"#fff5f5",
              padding:10,
              opacity:0.8,
              borderTopLeftRadius:30,
              borderTopRightRadius:30,
              borderBottomLeftRadius:30,
              borderBottomRightRadius:30,
              fontWeight:"bold",
              flexDirection:'row',
              alignItems:"center",
              
        }}
        >
       <View
       style={{
         flex:3,
         marginLeft:15
       }}
       >
        <Text
        style={{
          fontWeight:"bold",
          fontSize:14,
          color:'black'
        }}
       >
        Politeknik Caltex Riau
       </Text>
        <Text
         style={{
          fontSize:9,
          color:'black',
          marginTop:5,
        }}
        >Kumpulan Informasi Fasilitas Kampus PCR    Motto : Empowers You to Global Competation</Text>
       </View>

       <View
       style={{
         flex:1,
         backgroundColor:'#c9c9c9',
         height:70,
         borderRadius:20,
         justifyContent:"center",
         alignItems:"center",
         marginRight:20
       }}
       ><Text
       style={{
          fontSize:25,
          color:'orange',
          marginTop:5,
          fontWeight:"bold"
        }}
       >5+</Text></View>
       
        </View>
        <View
        style={{
          backgroundColor:'#fff5f5',
          height:225,
          marginTop:30,
          borderRadius:40
        }}
        >
        <View
         style={{
         flex:1,
         height:70,
         borderRadius:20,
         justifyContent:"space-around",
         flexDirection:'row',
         padding:40
       }}>
        <View
        style={{
          alignItems:"center"
        }}
        >
        <TouchableOpacity onPress={()=> navigation.navigate('Cari')}>
        <Ionicons name="grid" size={20} color="orange"/>
        </TouchableOpacity>
        <Text
        style={{
          flexWrap:"center"
        }}
        >Fasilitas </Text>
        </View>
        <View
        style={{
          alignItems:"center"
        }}
        >
        <TouchableOpacity onPress={()=> navigation.navigate('Peminjaman')}>
          <Ionicons name="receipt" size={20} color="#26b594"/>
          </TouchableOpacity>
          <Text> Peminjaman </Text>
        </View>
        </View>
        <View
         style={{
         flex:1,
         height:70,
         borderRadius:20,
         justifyContent:"space-around",
         flexDirection:'row',
         padding:40
       }}>
        <View
        style={{
          alignItems:"center"
        }}
        >
        <Ionicons name="people" size={20} color="orange"/>
        
        <Text
        style={{
          flexWrap:"center"
        }}
        >Peminjam </Text>
        </View>
        <View
        style={{
          alignItems:"center"
        }}
        >
          <Ionicons name="ellipsis-vertical" size={20} color="#26b594"/>
          <Text> Kategori </Text>
        </View>
        </View>
        <View>
        </View> </View>
    </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    padding: 8,
  },
  header:{
    flexDirection:'row',
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    alignItems:"center",
    justifyContent:"space-between",
    
  }
});