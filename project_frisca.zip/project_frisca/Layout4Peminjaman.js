import React,{useState,useEffect} from 'react';
import axios from 'axios';
import Constants from 'expo-constants';
import { FlatList, ActivityIndicator, StyleSheet, Image, Text, View,Dimensions,TouchableOpacity } from 'react-native';
 
// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';
import { Ionicons } from '@expo/vector-icons';
const windowWidth = Dimensions.get('window').width;
const windowHeight = Dimensions.get('window').height;

export default function Layout4Peminjaman({navigation}){
  const [peminjaman,setPeminjaman]=useState([])
    const getPeminjaman = async () => {
      try {
        const dataFasilitas = await axios.get(
          'https://murmuring-lowlands-06200.herokuapp.com/api/peminjaman'
        );
        setPeminjaman(dataFasilitas.data);
        console.log(dataFasilitas.data);
      }catch (err) {
        console.error(err.message);
      }
    };
    useEffect(()=>{
      getPeminjaman()
    },[]
    )
       return (
         <View>
    <View>
          <Image source={{uri:'https://i.pinimg.com/474x/b0/cb/5a/b0cb5aed176f13b6e2a265d8671cb323.jpg'}} 
          style={{
            height:700,
            borderTopLeftRadius:20,
            borderTopRightRadius:20,
            borderBottomLeftRadius:20,
            borderBottomRightRadius:20,
            position:"absolute",
            zIndex:-999,
            top: 0,
            bottom: 0,
            left: 0,
            right: 0,
          }}
          />
      </View>
    <View style={styles.container}>
        <View
        style={{
          backgroundColor:'white',
          flex:1,
          marginTop:30,
          borderRadius:40
        }}
        >
        <View
         style={{
         flex:1,
         height:70,
         borderRadius:20,
         alignContent:'flex-start',
         flexDirection:'row',
         padding:20
       }}>
        <View>
        <TouchableOpacity onPress={()=> navigation.navigate('Home')}>
         <Ionicons name="arrow-back-outline" size={20} color="black"
            style={{
              backgroundColor:"#fff5f5",
              padding:10,
              borderRadius:60,
            }}
            />
        </TouchableOpacity>
        </View>
        </View>
    <View
    style={{
         flex:3,
         marginLeft:15
       }}>
      <Text
        style={{
          fontSize:18,
          color:'grey',
          marginTop:25
        }}
       >Daftar Peminjaman peminjaman
       </Text> 
    </View>
    
 <FlatList
                   data={peminjaman}
                   renderItem={({ item }) => (
                     <>
                     
                     <View style={{
                       marginLeft:10,
                       marginTop:10,
                       marginBottom:10,
                       justifyContent:"space-between",
                       flexDirection:"row",
                       alignItems:'center',
                       padding:10,
                       width:300,
                       borderRadius:20,
                       backgroundColor:'pink'
                     }}>
                      <View
                      style={{
                        flexDirection:'row',
                      }}
                      >
                          <View>
                         
                           <Text
                          style={{
                            paddingLeft:20,
                            fontWeight:"bold"
                          }}
                          >{item.id_peminjam.nama}</Text>
                           <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Email : {item.id_peminjam.email}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Tgl Peminjam : {item.tgl}</Text>
                           <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Ket : {item.kegiatan}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >No Hp : {item.id_peminjam.nohp}</Text>
                          <Text
                          style={{
                            paddingLeft:20,
                            fontSize:12
                          }}
                          >Alamat : {item.id_peminjam.alamat}</Text>
                          </View>
                      </View>
                     </View>
                     </>
                      )}
                   keyExtractor={({ id }, index) => id}
               />

      </View>
        </View>
        </View>
       );

 
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: Constants.statusBarHeight,
    padding: 0,
  },
  header:{
    flexDirection:'row',
    marginTop:20,
    marginLeft:20,
    marginRight:20,
    alignItems:"center",
    justifyContent:"space-between",
  },
  peminjaman: {
    padding:10,
    flexDirection:'row',
    alignItems:'center',
    backgroundColor:'white',
    height:70,
    justifyContent:'space-between',
    borderRadius:30,
    marginTop:20
  },
  gambar:{
    height:95,
    width:75,
    borderRadius:10,
    borderWidth:1,
    position:'flex'
  },
});